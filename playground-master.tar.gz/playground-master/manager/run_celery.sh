celery worker -A celery_.celery --loglevel=info
